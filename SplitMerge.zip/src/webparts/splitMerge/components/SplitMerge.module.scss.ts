
require("./SplitMerge.module.css");
const styles = {
  splitMerge: 'splitMerge_eec56e99',
  teams: 'teams_eec56e99',
  modalContainer: 'modalContainer_eec56e99',
  modalHeader: 'modalHeader_eec56e99',
  modalBody: 'modalBody_eec56e99',
  modalContent: 'modalContent_eec56e99',
  previewPanel: 'previewPanel_eec56e99',
  previewControls: 'previewControls_eec56e99',
  currentPageLabel: 'currentPageLabel_eec56e99',
  previewCanvasWrapper: 'previewCanvasWrapper_eec56e99',
  previewCanvas: 'previewCanvas_eec56e99',
  selectionPanel: 'selectionPanel_eec56e99',
  pageSelectionList: 'pageSelectionList_eec56e99',
  pageSelectionItem: 'pageSelectionItem_eec56e99',
  formSection: 'formSection_eec56e99',
  'ms-TextField': 'ms-TextField_eec56e99',
  'ms-Button': 'ms-Button_eec56e99',
  welcome: 'welcome_eec56e99',
  welcomeImage: 'welcomeImage_eec56e99',
  links: 'links_eec56e99'
};

export default styles;
