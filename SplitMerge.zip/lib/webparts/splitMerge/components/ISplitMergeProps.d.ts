import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface ISplitMergeProps {
    title: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    sourceLibraryTitle: string;
    destinationLibraryTitle: string;
    documentTypeConfigListTitle: string;
    context: WebPartContext;
}
//# sourceMappingURL=ISplitMergeProps.d.ts.map