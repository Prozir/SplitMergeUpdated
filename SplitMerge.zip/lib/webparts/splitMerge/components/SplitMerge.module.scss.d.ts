declare const styles: {
    splitMerge: string;
    teams: string;
    modalContainer: string;
    modalHeader: string;
    modalBody: string;
    modalContent: string;
    previewPanel: string;
    previewControls: string;
    currentPageLabel: string;
    previewCanvasWrapper: string;
    previewCanvas: string;
    selectionPanel: string;
    pageSelectionList: string;
    pageSelectionItem: string;
    formSection: string;
    'ms-TextField': string;
    'ms-Button': string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=SplitMerge.module.scss.d.ts.map