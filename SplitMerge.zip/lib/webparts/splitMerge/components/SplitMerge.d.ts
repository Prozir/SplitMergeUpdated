import * as React from 'react';
import type { ISplitMergeProps } from './ISplitMergeProps';
import { IDropdownOption } from '@fluentui/react';
interface IPageInfo {
    pageNumber: number;
    contractNumber: string;
    documentType: string;
    selected: boolean;
    thumbnail?: string;
}
export default class SplitMerge extends React.Component<ISplitMergeProps, {
    pdfFiles: any[];
    selectedPdf: string;
    selectedPdfName: string;
    pages: IPageInfo[];
    currentPageNumber: number;
    loading: boolean;
    newContractNumber: string;
    newDocumentType: string;
    uploading: boolean;
    uploadingSource: boolean;
    errorMessage: string;
    showModal: boolean;
    documentTypes: IDropdownOption[];
    loadingDocumentTypes: boolean;
}> {
    private pdfDocument;
    private previewCanvasRef;
    private fileInputRef;
    constructor(props: ISplitMergeProps);
    componentDidMount(): void;
    private initializePdfJs;
    componentDidUpdate(prevProps: ISplitMergeProps, prevState: Readonly<any>): void;
    private loadPdfFiles;
    private loadPdf;
    private loadDocumentTypes;
    private handleModalClose;
    private handlePdfSelect;
    private handleUploadButtonClick;
    private handleFileInputChange;
    private handlePageSelect;
    private renderPdfPage;
    private handlePageNavigation;
    private handleCollateAndUpload;
    render(): React.ReactElement<ISplitMergeProps>;
}
export {};
//# sourceMappingURL=SplitMerge.d.ts.map